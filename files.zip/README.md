# Khoi Nguyen Vu — Studentský web
## Struktura souborů projektu

```
khoi-web/
├── index.html          ← Stránka 1: O mně
├── skola.html          ← Stránka 2: O škole
├── budoucnost.html     ← Stránka 3: O budoucnosti
├── css/
│   └── style.css       ← Sdílené styly (všechny 3 stránky)
├── js/
│   └── main.js         ← Sdílený JS (navigace, hodiny, květiny)
├── img/                ← Složka pro vlastní fotky
│   ├── khoi.jpg        ← Tvoje profilová fotka (nahradit)
│   ├── study.jpg       ← Foto ze studia (nahradit)
│   ├── skola.jpg       ← Foto budovy OA (nahradit)
│   ├── trida.jpg       ← Foto ze třídy (nahradit)
│   └── mu.jpg          ← Logo nebo foto MU (nahradit)
└── README.md           ← Tento soubor
```

## Jak přidat vlastní fotky

1. Vlož své fotky do složky `img/`
2. V HTML souborech najdi komentáře jako `<!-- Nahraď src="img/khoi.jpg" -->`
3. Nahraď `<div class="img-placeholder">...</div>` za:
   ```html
   <img src="img/jmeno_souboru.jpg" alt="Popis fotky" />
   ```

## Publikace na GitHub Pages (ZDARMA)

### Krok 1 — Vytvoř účet na GitHub
- Jdi na https://github.com
- Zaregistruj se (zdarma)

### Krok 2 — Vytvoř nový repozitář
- Klikni na zelené tlačítko "New repository"
- Název repozitáře: `khoi-web` (nebo cokoliv chceš)
- Nastav na Public
- Klikni "Create repository"

### Krok 3 — Nahraj soubory
Varianta A (přes web — jednodušší):
- V repozitáři klikni "uploading an existing file"
- Přetáhni VŠECHNY soubory (index.html, skola.html, budoucnost.html, složky css/ js/ img/)
- Klikni "Commit changes"

Varianta B (přes Git):
```bash
git init
git add .
git commit -m "První verze webu"
git branch -M main
git remote add origin https://github.com/TVŮJ_USERNAME/khoi-web.git
git push -u origin main
```

### Krok 4 — Zapni GitHub Pages
- V repozitáři jdi do Settings (Nastavení)
- Levé menu → "Pages"
- Source: "Deploy from a branch"
- Branch: main, složka: / (root)
- Klikni Save

### Krok 5 — Počkej 2–3 minuty
GitHub vygeneruje adresu ve tvaru:
```
https://TVŮJ_USERNAME.github.io/khoi-web/
```

## Jak zkontrolovat, že odkaz vede přímo na web

✅ Správně: URL začíná `https://TVŮJ_USERNAME.github.io/`
   → Zobrazí se přímo tvůj web (index.html)

❌ Špatně: URL vede na `https://github.com/TVŮJ_USERNAME/khoi-web`
   → To je administrace repozitáře, ne web!

Testuj vždy v anonymním okně prohlížeče nebo jiném zařízení.

## Alternativa: Netlify (ještě jednodušší)

1. Jdi na https://netlify.com
2. Přetáhni celou složku `khoi-web/` na stránku
3. Netlify automaticky vygeneruje URL jako:
   `https://nahodne-jmeno.netlify.app`
4. Odkaz lze přejmenovat v nastavení

## Tipy pro lepší SEO

- Doplň vlastní fotky (zlepší vzhled i hodnocení)
- Přidej meta tag: `<meta name="author" content="Khoi Nguyen Vu">`
- Přidej favicon (ikona v záložce): `<link rel="icon" href="img/favicon.ico">`
