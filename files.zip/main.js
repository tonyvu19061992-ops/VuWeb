/* ================================================
   KHOI WEB — Sdílený JavaScript
   - Navigace (hamburger, active link)
   - Analogové hodiny
   - Padající květiny (stránka 1)
   - Fade-in animace při scrollu
   ================================================ */

/* ── NAVIGACE ───────────────────────────────────── */
document.addEventListener('DOMContentLoaded', () => {
  const toggle = document.getElementById('nav-toggle');
  const links  = document.getElementById('nav-links');

  if (toggle && links) {
    toggle.addEventListener('click', () => {
      toggle.classList.toggle('open');
      links.classList.toggle('open');
    });

    links.querySelectorAll('a').forEach(a => {
      a.addEventListener('click', () => {
        toggle.classList.remove('open');
        links.classList.remove('open');
      });
    });
  }

  /* Označit aktivní odkaz podle aktuální stránky */
  const page = window.location.pathname.split('/').pop() || 'index.html';
  document.querySelectorAll('.nav-links a').forEach(a => {
    if (a.getAttribute('href') === page) a.classList.add('active');
  });

  /* ── FADE-UP při scrollu ───────────────────── */
  const observer = new IntersectionObserver(entries => {
    entries.forEach(e => {
      if (e.isIntersecting) {
        e.target.classList.add('visible');
        observer.unobserve(e.target);
      }
    });
  }, { threshold: 0.12 });

  document.querySelectorAll('.fade-up').forEach(el => observer.observe(el));
});

/* ── ANALOGOVÉ HODINY ───────────────────────────── */
function initClock(canvasId) {
  const canvas = document.getElementById(canvasId);
  if (!canvas) return;

  const ctx    = canvas.getContext('2d');
  const size   = 220;
  canvas.width  = size;
  canvas.height = size;
  const cx = size / 2;
  const cy = size / 2;
  const R  = size / 2 - 4;

  function draw() {
    const now = new Date();
    const s   = now.getSeconds();
    const m   = now.getMinutes() + s / 60;
    const h   = (now.getHours() % 12) + m / 60;

    ctx.clearRect(0, 0, size, size);

    /* Pozadí */
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, 2 * Math.PI);
    const bg = ctx.createRadialGradient(cx, cy - 20, 5, cx, cy, R);
    bg.addColorStop(0, '#1E3A61');
    bg.addColorStop(1, '#0B1F3A');
    ctx.fillStyle = bg;
    ctx.fill();

    /* Zlatý kruh */
    ctx.beginPath();
    ctx.arc(cx, cy, R, 0, 2 * Math.PI);
    ctx.strokeStyle = '#C9A84C';
    ctx.lineWidth = 2.5;
    ctx.stroke();

    /* Minutové rysky */
    for (let i = 0; i < 60; i++) {
      const angle = (i / 60) * 2 * Math.PI - Math.PI / 2;
      const isHour = i % 5 === 0;
      const inner = R - (isHour ? 14 : 7);
      ctx.beginPath();
      ctx.moveTo(cx + Math.cos(angle) * inner, cy + Math.sin(angle) * inner);
      ctx.lineTo(cx + Math.cos(angle) * (R - 3), cy + Math.sin(angle) * (R - 3));
      ctx.strokeStyle = isHour ? '#C9A84C' : 'rgba(201,168,76,0.35)';
      ctx.lineWidth = isHour ? 2 : 1;
      ctx.stroke();
    }

    /* Číslice hodin */
    ctx.font = 'bold 13px "DM Sans", sans-serif';
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillStyle = '#E0C36A';
    for (let i = 1; i <= 12; i++) {
      const a = (i / 12) * 2 * Math.PI - Math.PI / 2;
      ctx.fillText(i, cx + Math.cos(a) * (R - 28), cy + Math.sin(a) * (R - 28));
    }

    /* Hodinová ručička */
    drawHand(ctx, cx, cy, (h / 12) * 2 * Math.PI - Math.PI / 2,
      R * 0.52, 5.5, '#FFFFFF');

    /* Minutová ručička */
    drawHand(ctx, cx, cy, (m / 60) * 2 * Math.PI - Math.PI / 2,
      R * 0.72, 3.5, '#FFFFFF');

    /* Sekundová ručička */
    drawHand(ctx, cx, cy, (s / 60) * 2 * Math.PI - Math.PI / 2,
      R * 0.80, 1.5, '#C9A84C');

    /* Střed */
    ctx.beginPath();
    ctx.arc(cx, cy, 6, 0, 2 * Math.PI);
    ctx.fillStyle = '#C9A84C';
    ctx.fill();
    ctx.beginPath();
    ctx.arc(cx, cy, 2.5, 0, 2 * Math.PI);
    ctx.fillStyle = '#FFFFFF';
    ctx.fill();

    /* Digitální čas pod hodinami */
    const tn = document.getElementById('clock-time-text');
    if (tn) {
      tn.textContent = now.toLocaleTimeString('cs-CZ', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    }
  }

  function drawHand(ctx, cx, cy, angle, len, width, color) {
    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(angle);
    ctx.beginPath();
    ctx.moveTo(0, -len);
    ctx.lineTo(0, len * 0.2);
    ctx.strokeStyle = color;
    ctx.lineWidth = width;
    ctx.lineCap = 'round';
    ctx.stroke();
    ctx.restore();
  }

  draw();
  setInterval(draw, 1000);
}

/* ── PADAJÍCÍ KVĚTINY ───────────────────────────── */
function initPetals(containerId) {
  const container = document.getElementById(containerId);
  if (!container) return;

  container.style.position = 'relative';
  container.style.overflow = 'hidden';

  const COLORS = ['#C9A84C', '#E0C36A', '#F0D080', '#ffffff', '#B8D4F4', '#F4A7B9'];
  const SHAPES = ['circle', 'ellipse', 'petal'];
  const COUNT  = 28;
  const petals = [];

  for (let i = 0; i < COUNT; i++) {
    const el = document.createElement('div');
    el.className = 'falling-petal';

    const size  = Math.random() * 14 + 7;
    const color = COLORS[Math.floor(Math.random() * COLORS.length)];
    const shape = SHAPES[Math.floor(Math.random() * SHAPES.length)];

    let borderRadius;
    if (shape === 'circle')  borderRadius = '50%';
    else if (shape === 'ellipse') borderRadius = '50% 50% 50% 50% / 60% 60% 40% 40%';
    else                          borderRadius = '0 60% 0 60%';

    Object.assign(el.style, {
      position: 'absolute',
      width:  size + 'px',
      height: size + (shape === 'ellipse' ? size * 0.6 : size) + 'px',
      background: color,
      borderRadius,
      opacity: (Math.random() * 0.5 + 0.25).toString(),
      pointerEvents: 'none',
      zIndex: '1',
    });

    const petal = {
      el,
      x:     Math.random() * 100,      // % šířky
      y:    -10 - Math.random() * 100, // startuje nad kontejnerem
      vy:    Math.random() * 0.03 + 0.015,
      vx:    (Math.random() - 0.5) * 0.015,
      rot:   Math.random() * 360,
      vrot:  (Math.random() - 0.5) * 1.5,
      wobble: Math.random() * Math.PI * 2,
      wobbleSpeed: Math.random() * 0.03 + 0.01,
    };

    container.appendChild(el);
    petals.push(petal);
  }

  function tick() {
    const H = container.offsetHeight;
    const W = container.offsetWidth;

    petals.forEach(p => {
      p.y += p.vy * 100;
      p.wobble += p.wobbleSpeed;
      p.x += p.vx * 100 + Math.sin(p.wobble) * 0.08;
      p.rot += p.vrot;

      if (p.y > 110) {
        p.y = -15;
        p.x = Math.random() * 100;
      }

      const px = (p.x / 100) * W;
      const py = (p.y / 100) * H;
      p.el.style.transform = `translate(${px}px, ${py}px) rotate(${p.rot}deg)`;
    });

    requestAnimationFrame(tick);
  }

  requestAnimationFrame(tick);
}
